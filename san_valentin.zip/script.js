
function mostrarMensaje() {
    document.getElementById("mensaje").innerHTML = "❤️ ¡Eres mi persona favorita! ❤️";
}
